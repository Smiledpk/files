# Uber App UI Clone in React Native(Expo)

![Alt Text](https://github.com/nathvarun/Uber-App-UI-Clone-React-Native/blob/master/demo/Uber-Ui-Demo.gif?raw=true)


## YouTube Tutorial Video 
* ###  [Uber UI Clone Login Screen](https://www.youtube.com/watch?v=e1xi0NfpkfI&list=PLy9JCsy2u97lqwG1DiaUA9RPloJ0Ok2wb) 

## Installation Instructions 

```js
 $ git clone https://github.com/nathvarun/Uber-App-UI-Clone-React-Native.git
 $ cd /Uber-App-UI-Clone-React-Native
 $ npm install 
```